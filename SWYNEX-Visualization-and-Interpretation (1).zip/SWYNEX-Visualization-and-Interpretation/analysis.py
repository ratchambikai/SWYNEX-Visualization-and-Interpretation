"""
SWYNEX Task 3: Visualization and Interpretation
This project uses a clearly labelled SYNTHETIC sample dataset.
It is not real SWYNEX company data.
Run from this folder:
    python analysis.py
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "sample_sales_data.csv"
CHARTS = ROOT / "charts"
CHARTS.mkdir(exist_ok=True)

df = pd.read_csv(DATA, parse_dates=["date"])

# Basic checks
print("Dataset shape:", df.shape)
print("\nMissing values:\n", df.isnull().sum())
print("\nPreview:\n", df.head())

monthly = df.groupby(df["date"].dt.strftime("%b"))["revenue_usd"].sum()
month_order = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
monthly = monthly.reindex(month_order)
region = df.groupby("region")["revenue_usd"].sum().sort_values(ascending=False)
product = df.groupby("product")["revenue_usd"].sum().sort_values(ascending=False)

# Chart 1: monthly revenue
plt.figure(figsize=(9, 5))
plt.plot(monthly.index, monthly.values, marker="o")
plt.title("Monthly Revenue Trend (Synthetic Sample Data)")
plt.xlabel("Month")
plt.ylabel("Revenue (USD)")
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig(CHARTS / "01_monthly_revenue.png", dpi=160)
plt.close()

# Chart 2: revenue by region
plt.figure(figsize=(8, 5))
plt.bar(region.index, region.values)
plt.title("Revenue by Region (Synthetic Sample Data)")
plt.xlabel("Region")
plt.ylabel("Revenue (USD)")
plt.tight_layout()
plt.savefig(CHARTS / "02_revenue_by_region.png", dpi=160)
plt.close()

# Chart 3: revenue by product
plt.figure(figsize=(8, 5))
plt.bar(product.index, product.values)
plt.title("Revenue by Product (Synthetic Sample Data)")
plt.xlabel("Product")
plt.ylabel("Revenue (USD)")
plt.tight_layout()
plt.savefig(CHARTS / "03_revenue_by_product.png", dpi=160)
plt.close()

# Chart 4: transaction revenue distribution
plt.figure(figsize=(8, 5))
plt.hist(df["revenue_usd"], bins=18, edgecolor="black")
plt.title("Distribution of Transaction Revenue (Synthetic Sample Data)")
plt.xlabel("Revenue per record (USD)")
plt.ylabel("Number of records")
plt.tight_layout()
plt.savefig(CHARTS / "04_revenue_distribution.png", dpi=160)
plt.close()

print("\nTop region:", region.index[0], f"(${region.iloc[0]:,.2f})")
print("Top product:", product.index[0], f"(${product.iloc[0]:,.2f})")
print("Highest revenue month:", monthly.idxmax(), f"(${monthly.max():,.2f})")
print("\nCharts saved in:", CHARTS)
