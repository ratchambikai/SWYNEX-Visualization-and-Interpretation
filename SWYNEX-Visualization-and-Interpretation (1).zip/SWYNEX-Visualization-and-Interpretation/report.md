# Task 3 Report: Visualization and Interpretation

## 1. Objective
To demonstrate how tabular data can be summarized through charts and interpreted carefully.

## 2. Dataset description
The dataset contains 144 synthetic records across 12 months, four fictional sales regions, and three product categories. It includes date, region, product, units sold, unit price, and revenue. Revenue is calculated as units sold multiplied by unit price. This dataset is for practice only and is not actual SWYNEX data.

## 3. Visualizations and interpretation

### Chart 1 – Monthly revenue trend
The line chart compares total recorded revenue across the 12 months. In this sample, Jun has the highest total (87,434.04 USD), while Mar has the lowest (67,696.13 USD). This describes the pattern in the generated sample. It does not prove why revenue changed, predict future revenue, or establish a real seasonal business pattern.

### Chart 2 – Revenue by region
The bar chart compares total revenue across the four regions. North has the largest total (246,109.61 USD) in this sample. This does not prove that the region has more customers, better staff, or higher profitability. Revenue is not the same as profit, and the sample is fictional.

### Chart 3 – Revenue by product
The bar chart compares total revenue across products. Laptop has the largest total (549,539.37 USD) in this sample. This does not prove that it is the most profitable product or the most popular by number of units; price and quantity both affect revenue.

### Chart 4 – Transaction revenue distribution
The histogram shows how individual record-level revenue values are distributed. The mean transaction revenue is 6,226.02 USD and the median is 4,106.64 USD. The histogram can show concentration and spread, but it does not explain the cause of high or low values or establish that the distribution represents a real company's transactions.

## 4. Scientific interpretation and limitations
- The charts summarize the values present in the dataset; they do not establish causation.
- The dataset is artificially generated, so the findings cannot be generalized to SWYNEX or any real business.
- No costs, discounts, returns, taxes, customer counts, or profit data are included.
- The time period is only one year and does not establish a long-term trend.
- A larger, verified, representative dataset would be needed for stronger conclusions.

## 5. Conclusion
The project demonstrates four common visualization methods and explains both their useful insights and their limitations. The results are examples from synthetic data, not evidence about SWYNEX's actual operations.

## 6. Suggested next step
Confirm the approved data source and submission expectations with the SWYNEX mentor/reviewer. Replace the sample dataset and revise all numerical findings before presenting this as an analysis of real data.
