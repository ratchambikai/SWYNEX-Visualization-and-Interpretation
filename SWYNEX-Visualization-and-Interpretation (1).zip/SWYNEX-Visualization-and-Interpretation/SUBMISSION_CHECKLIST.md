# Before submitting
- [ ] Confirm with SWYNEX whether synthetic data is acceptable.
- [ ] If required, replace the sample CSV with an approved dataset.
- [ ] Re-run `python analysis.py` and check all four charts.
- [ ] Update the report so every statement matches the actual dataset.
- [ ] Keep the repository name: SWYNEX-Visualization-and-Interpretation.
- [ ] Test the GitHub repository link in a private/incognito browser.
- [ ] Test the LinkedIn post link in a private/incognito browser.
- [ ] Do not publish confidential or personal data.
